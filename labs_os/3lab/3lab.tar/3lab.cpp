#include <algorithm>
#include <iostream>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <stdbool.h>
#include <pthread.h>
#include <semaphore.h>


using namespace std;

unsigned long long nProcess = 1;
sem_t semaphore;

typedef struct {
    unsigned long long *l;
    unsigned long long *r;
    bool inv;
    unsigned long long level;
} Data;


void* bitseqsort(void *thdata) {

    Data *data = new Data;
    data->l =  ((Data*)(thdata))->l;
    data->r =  ((Data*)(thdata))->r;
    data->inv =  ((Data*)(thdata))->inv;
    data->level =  ((Data*)(thdata))->level;

    int rv;
	if (data->r - data->l <= 1) return NULL;
	unsigned long long *m = data->l + (data->r - data->l) / 2;
	for (unsigned long long *i = data->l, *j = m; i < m && j < data->r; i++, j++) {
		if (data->inv ^ (*i > *j)) swap(*i, *j);
	}

    Data *putl = new Data;
    putl->l = data->l;
    putl->r =  m;
    putl->inv = data->inv;
    putl->level = (data->level)+1;

    Data *putr = new Data;
    putr->l = m+1;
    putr->r = data->r;
    putr->inv = data->inv;
    putr->level = (data->level)+1;

    int curProc;
    sem_getvalue(&semaphore, &curProc);
    //cout << "Sema: " << curProc << endl;

        if(curProc == 0){
            bitseqsort(putl);
            bitseqsort(putr);
        } else {
       
            pthread_t thread_pid;
            pthread_attr_t attr;
            pthread_attr_init(&attr);
            pthread_attr_setscope(&attr, PTHREAD_SCOPE_PROCESS);


            sem_wait(&semaphore);

            if(pthread_create(&thread_pid, NULL, bitseqsort, putl)) {
                cout << "ERROR creating thread" << endl;
                exit(1);
            }
            
            
            bitseqsort(putr);
            
            
            if(pthread_join(thread_pid, NULL)) {
                cout << "ERROR joining thread" << endl;
                exit(1);
            }
            sem_post(&semaphore);
        }
    

    delete data;
    delete putl;
    delete putr;
    
    return NULL;
}

void* makebitonic(void* thdata);

void* make_n_sort(void *thdata) {
    Data *data = new Data;
    data->l =  ((Data*)(thdata))->l;
    data->r =  ((Data*)(thdata))->r;
    data->inv =  ((Data*)(thdata))->inv;
    data->level =  ((Data*)(thdata))->level;

    makebitonic(data);
    data->level = 0;
	bitseqsort(data);
    delete data;
}


// делает послдовательность битонной
// дозаполняем ее элементами больше максимального, не влияет на ассимптотику
void* makebitonic(void* thdata) {
    
    Data *data = new Data;
    data->l =  ((Data*)(thdata))->l;
    data->r =  ((Data*)(thdata))->r;
    data->inv =  ((Data*)(thdata))->inv;
    data->level =  ((Data*)(thdata))->level;

	if (data->r - data->l <= 1) {
        return NULL;
    }

    // находим центр
	unsigned long long *m = data->l + (data->r - data->l) / 2;

    Data *putL = new Data;
    putL->l = data->l;
    putL->r = m;
    putL->inv = 0;
    putL->level = (data->level) + 1;

    Data *putR = new Data;
    putR->l = m+1;
    putR->r = data->r;
    putR->inv = 1;
    putR->level = (data->level) + 1;

    
    int curProc;
    sem_getvalue(&semaphore, &curProc);
    
    if(curProc == 0){
            bitseqsort(putL);
            bitseqsort(putR);
    } else {

        
        pthread_t thread_pid;
        pthread_attr_t attr;
        pthread_attr_init(&attr);
        pthread_attr_setscope(&attr,PTHREAD_SCOPE_PROCESS);

        sem_wait(&semaphore);
        
        if(pthread_create(&thread_pid, NULL, make_n_sort, putL)) {
            cout << "ERROR creating thread" << endl;
            exit(1);
        }


        make_n_sort(putR);
        if(pthread_join(thread_pid, NULL)) {
            cout << "ERROR joining thread" << endl;
            exit(1);
        }

        sem_post(&semaphore);
        
    }
    

    delete data;
    delete putL;
    delete putR;
}
void bitonicsort(unsigned long long* l, unsigned long long* r) {
	unsigned long long n = 1;
	unsigned long long inf = *max_element(l, r) + 1;

	while (n < r - l) n *= 2;

	unsigned long long *a = new unsigned long long[n];
	unsigned long long cur = 0;

    // *копируем массив в а
	for (unsigned long long *i = l; i < r; i++){
		a[cur++] = *i;
    }

	while (cur < n) a[cur++] = inf;  // дозаполнение элементов

    Data *put = new Data;
    put->l = a;
    put->r = a+n;
    put->inv = 0;
    put->level = 0;
    
    
	makebitonic(put);
    put->level = 0;

	bitseqsort(put);


	cur = 0;
	for (unsigned long long *i = l; i < r; i++)
		*i = a[cur++];

	delete a;
    delete put;
}

int main() {

    unsigned long long Num = 10000;
    unsigned long long b[10000];
   
    for(unsigned long long i = 0; i < Num; i++) {
        b[i] = ((unsigned long long)(rand()))%100;
    }

    for(nProcess = 1; nProcess < 3; nProcess++){
        sem_init(&semaphore, 0, nProcess);
            
        unsigned long long a[10000];

        for(unsigned long long i = 0; i < Num; i++){
            a[i] = b[i];
        }
    
        bitonicsort(a, (a+Num));
        sem_destroy(&semaphore);
    }
        
    return 0;
}