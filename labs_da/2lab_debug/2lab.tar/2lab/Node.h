#ifndef NODE_H
#define NODE_H
#include <string.h>

typedef enum { BLACK, RED } nodeColor;

class Node {
    public:
        nodeColor color; // enumed color
        Node *left;
        Node *right;
        Node *parent;
        unsigned long long m_value = 0;
        char m_key[260] = {'\0'};

        Node(char *key, unsigned long long value){
            if(key != nullptr)
                for(int i = 0; (i <= 260 && key[i] != '\0'); i++){
                    this->m_key[i] = key[i];
                }            
            this->m_value = value;
            this->color = RED;
        };
        Node(nodeColor color, Node *left, Node *right, 
            Node *parent,  char *key, unsigned long long value){
                
                this->color = color;
                /*if(key != nullptr)
                    for(int i = 0; i < 257 && key[i] == '\0'; i++){
                        this->m_key[i] = key[i];
                    }
                */
                strcpy(m_key, key);            
                this->m_value = value;
                this->left = left;
                this->right = right;
                this->parent = parent;
            }
        
        Node(){ 
        };
        ~Node(){
            
        };
    };
#endif

