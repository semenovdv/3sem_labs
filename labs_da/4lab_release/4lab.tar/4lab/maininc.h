#ifndef MAININC_H
#define MAININC_H

#include <iostream>
#include <string>
#include <map>
#include <vector>
#include <algorithm>
#include <queue>

#endif
